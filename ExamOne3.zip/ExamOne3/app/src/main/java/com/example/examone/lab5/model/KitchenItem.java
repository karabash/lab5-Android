package com.example.examone.lab5.model;


public class KitchenItem {
    private String _id;
    private String name;
    private  String picture;

    public KitchenItem( String name, String picture, String _id) {
        this.name = name;
        this.picture =picture;
        this._id = _id;
    }


    // Getter Methods
    public String get_id() {
        return _id;
    }

    public String getName() {
        return name;
    }

    public String getPicture() {
        return picture;
    }




}