package com.example.examone.lab5.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.examone.R;

/**
 * Responsible for changing view, depends on clicked nutton
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * It starts the TatelineActivity
     *
     * @param view passes as argument when clicked on SHOW TATELINE on the UI
     */
    public void openActivityTateLine(View view) {
        Intent intent = new Intent(getApplicationContext(), WebPageShowerActivity.class);
        startActivity(intent);
    }

    /**
     * it starts the TtemKitchenActivity
     *
     * @param view passes as argument when clicked on SHOW ITEM IN KITCHEN on the UI
     */
    public void openActivityItemKitchen(View view) {
        Intent intent = new Intent(getApplicationContext(), KitchenActivity.class);
        startActivity(intent);
    }
}
