package com.example.examone.lab5.activities;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import com.example.examone.R;
import com.example.examone.lab5.activities.IContracts.ILoader;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;

/**
 * This class is responsible for loading url and show on UI
 */
public class WebPageShowerActivity extends AppCompatActivity implements ILoader {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.testlayout);
        loadPage(Links.TASTELINE.linkRetriever());
    }

    /**
     * Overrides to click / press back
     */
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }


    /**
     * This methods load the page
     *
     * @param url an url link
     */
    private void loadPage(String url) {
        webView = findViewById(R.id.viewOfTateLine);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(url);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
    }


    @Override
    public void loader(String url) {
        loadPage(url);
    }

    /**
     * This abstract enum contains link/ links to use by own outerclass
     */
    private enum Links {
        TASTELINE {
            public String linkRetriever() {
                return "https://www.tasteline.com/";
            }
        },
        // it's only for testing - a dummy link
        UU {
            public String linkRetriever() {
                return "https://uu.se/";
            }
        };

        /**
         * This method a contract for enum constants
         *
         * @return url link
         */
        public abstract String linkRetriever();
    }


}





