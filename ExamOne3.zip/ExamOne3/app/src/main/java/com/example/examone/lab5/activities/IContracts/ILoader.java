package com.example.examone.lab5.activities.IContracts;

@FunctionalInterface
public
interface ILoader {
    void loader(String url);
}
