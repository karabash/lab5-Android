package com.example.examone.lab5.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;

import android.os.Bundle;
import android.widget.Toast;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import com.example.examone.R;
import com.example.examone.lab5.adapter.KitchenAdapter;
import com.example.examone.lab5.model.KitchenItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;



public class KitchenActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    ArrayList<KitchenItem> dataModelArrayList = new ArrayList<KitchenItem>();

    /**
     *   fetch link and set  outs layout
     * @param savedInstanceState to stored the data of activity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final String LINK = "https://kitchen-help.herokuapp.com/kitchen";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kitchen);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        fetchByOnresponse(LINK);
    }

    /**
     * This method makes request by Volley
     * @param link web link pass as argument to fetch json data as link by StringRequest
     */
    private void fetchByOnresponse(String link) {
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, link,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Gson gson = new Gson();
                            Type collectionType = new TypeToken<ArrayList<KitchenItem>>(){}.getType();
                            dataModelArrayList = gson.fromJson(response.toString(), collectionType);
                             recyclerView.setAdapter(new KitchenAdapter(dataModelArrayList));

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        requestQueue.add(stringRequest);
    }

}

