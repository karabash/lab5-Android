package com.example.examone.lab5.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.examone.R;
import com.example.examone.lab5.model.KitchenItem;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


public class KitchenAdapter extends RecyclerView.Adapter<KitchenAdapter.MyViewHolder> {
    private ArrayList<KitchenItem> modelInstanceArrayList;

    public KitchenAdapter(ArrayList<KitchenItem> myDataset) {
        modelInstanceArrayList = myDataset;
    }

    /**
     * Create new views (invoked by the layout manager)
     * @param parent The ViewGroup into which the new View will be added after it is bound to an adapter position.
     * @param viewType The view type of the new View.
     * @return
     */
    @Override
    public KitchenAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view
        View rowView = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_layout, parent, false);
        TextView t = rowView.findViewById(R.id.item_text);
        Button b = rowView.findViewById(R.id.item_button);
        ImageView image = (ImageView) rowView.findViewById(R.id.item_image);
        MyViewHolder vh = new MyViewHolder(rowView, t, b, image);
        return vh;
    }




    /**
     *Replace the contents of a view (invoked by the layout manager)
     * @param holder  replace the contents of the view with that element
     * @param position get element from your dataset at this position
     */
    @Override
    public void onBindViewHolder(final MyViewHolder holder, int position) {
        holder.button.setTag(R.id.pos, position);
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                final KitchenItem item = modelInstanceArrayList.get((int) view.getTag(R.id.pos));
                //  RequestQueue requestQueue = Volley.newRequestQueue(view.getContext());
                System.out.println(item.toString());
               new Del().del(view, modelInstanceArrayList);
            }
        });
        ImageView image = (ImageView) holder.imageView.findViewById(R.id.item_image);
        holder.textView.setText(modelInstanceArrayList.get(position).getName());
        Picasso.get().load(modelInstanceArrayList.get(position).getPicture()).into(image);
    }


    /**
     * This method returns size of ArrayList
     * @return size of modelInstanceArrayList
     */
    @Override
    public int getItemCount() {
        return modelInstanceArrayList.size();
    }

    /**
     * initialoze android View, TextView, Button and ImageView
     */
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public View curView;
        public TextView textView;
        public Button button;
        public ImageView imageView;


        public MyViewHolder(View rowView, TextView textView, Button button, ImageView imageView) {
            super(rowView);
            this.curView = rowView;
            this.textView = textView;
            this.button = button;
            this.imageView = imageView;
        }
    }

    /**
     * makes delete request
     */
    private class Del {
        private StringBuilder sb = new StringBuilder("https://kitchen-help.herokuapp.com/kitchen/");

        /**
         * This method makes delete request
         * @param view pass view
         * @param modelOfArrayList item of contents
         */
        private void del(View view, ArrayList<KitchenItem> modelOfArrayList) {
            RequestQueue requestQueue = Volley.newRequestQueue(view.getContext());
            StringRequest mStringRequest = new StringRequest(Request.Method.DELETE, sb.append(modelOfArrayList.get((int) view.getTag(R.id.pos)).get_id()).toString(),
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                modelOfArrayList.remove((int) view.getTag(R.id.pos));
                                notifyDataSetChanged();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //displaying the error in toast if occurrs
                        }
                    });
            requestQueue.add(mStringRequest);
        }
    }


}